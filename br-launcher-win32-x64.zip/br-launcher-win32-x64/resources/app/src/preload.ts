// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.

import {join} from 'path'
import {readFileSync, writeFileSync} from 'fs'

class RegionInfo {
  $type: string;
  DefaultIp: string;
  Fqdn: string;
  Name: string;
  Port: number;
  TranslateName: number;
  constructor(name: string, ip: string, port: number, translateName?: number) {
    this.$type = "DnsRegionInfo, Assembly-CSharp";
    this.DefaultIp = ip;
    this.Name = name;
    this.Fqdn = ip;
    this.Port = port;
    this.TranslateName = translateName || 1003;
  }
}

interface AmongUsRegionInfoConfig {
  CurrentRegionIdx: number;
  Regions: RegionInfo[];
}

window.addEventListener("DOMContentLoaded", () => {
  const launchButton = document.querySelector('.launch-button')
  const uninstallButton = document.querySelector('.uninstall-button')
  const errorText = document.querySelector('.error-text')
  const subtitle = document.querySelector('.subtitle')
  let isLaunching = false;
  function getDirectory(): string {
    return join(process.env.APPDATA || join(process.env.HOME, ".steam/steam/steamapps/"), "/../LocalLow/Innersloth/Among Us/regioninfo.json")
  }
  
  function checkInstall() {
    const fileData = loadFile()
    if(!fileData) return;
    uninstallButton.classList.remove('hidden')
    launchButton.classList.remove('hidden')
    subtitle.innerHTML = "";

    if(fileData.Regions.find(e => e.Name == "100 Player BR")) {
      launchButton.classList.add('hidden')
      subtitle.innerHTML = "The 100 Player mod is installed, launch the game and select the region to join a game when we host."
    } else {
      uninstallButton.classList.add('hidden')
    }

  }

  function loadFile(): AmongUsRegionInfoConfig | undefined {
    let file: Buffer | undefined;
    try {
      file = readFileSync(getDirectory())
    } catch(e) {
      file = undefined
      return;
    }
    if(!file) {
      errorText.innerHTML = "No permission to access files or files dont exist, try opening the game and closing to regenerate it"
    }
    const fileString = file.toString()
    let fileData: AmongUsRegionInfoConfig;
    try{
      fileData = JSON.parse(fileString)
    } catch (e) {
      errorText.innerHTML = "File is invalid, try opening the game and closing to regenerate it"
      return;
    }
    return fileData;

  }

  function configureMod() {
    const fileData = loadFile()
    if(!fileData) return;
    try{
      if(fileData.Regions.find(e => e.Name == "100 Player BR")) {
        errorText.innerHTML = "Already Configured!"
        return;
      }
      fileData.CurrentRegionIdx = fileData.Regions.push(new RegionInfo("100 Player BR", "138.197.72.203", 22023))
    } catch (e) {
      errorText.innerHTML = "File is invalid, try opening the game and closing to regenerate it"
      return;
    }
    try {
      const outputData = Buffer.from(JSON.stringify(fileData))
      writeFileSync(getDirectory(), outputData)
    } catch (e) {
      errorText.innerHTML = "Cannot write to file!"
      return;
    }
  }

  function uninstallMod() {
    const fileData = loadFile()
    if(!fileData) return;
    try{
      fileData.CurrentRegionIdx = 0
      fileData.Regions.splice(fileData.Regions.findIndex(info => info.Name == "100 Player BR"), 1)
    } catch (e) {
      errorText.innerHTML = "File is invalid, try opening the game and closing to regenerate it"
      return;
    }
    try {
      const outputData = Buffer.from(JSON.stringify(fileData))
      writeFileSync(getDirectory(), outputData)
    } catch (e) {
      errorText.innerHTML = "Cannot write to file!"
      return;
    }
    
  }

  launchButton.addEventListener('click', async ev => {
    if(isLaunching) {
      ev.preventDefault()
      return;
    }
    isLaunching = true
    launchButton.innerHTML = "configuring..."
    configureMod()
    isLaunching = false
    launchButton.innerHTML = "configure"
    const fileData = loadFile()
    checkInstall()
  })

  uninstallButton.addEventListener('click', ev => {
    if(isLaunching) {
      ev.preventDefault()
      return;
    }
    isLaunching = true
    uninstallMod()
    isLaunching = false
    const fileData = loadFile()
    checkInstall()
  })

  checkInstall()

});
